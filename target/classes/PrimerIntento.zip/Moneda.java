public class Moneda {
        private String moneda;
        private double valor;

    // Constructor
        public Moneda(String moneda, double valor) {
            this.moneda = moneda;
            this.valor = valor;
        }


    // Métodos getter
        public String getMoneda() {
            return moneda;
        }

        public double getValor() {
            return valor;
        }

        // Método toString para imprimir el objeto
        @Override
        public String toString() {
            return "Tipo de Moneda { nombre = " + moneda +
                    ", valor = " + valor +'}';
        }

    }
