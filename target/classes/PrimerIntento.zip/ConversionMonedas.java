import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public record ConversionMonedas(
        String result,
        String documentation,
        String terms_of_use,
        LocalTime time_last_update_unix,
        LocalTime time_last_update_utc,
        LocalTime time_next_update_unix,
        LocalTime time_next_update_utc,
        String base_code) {
}
