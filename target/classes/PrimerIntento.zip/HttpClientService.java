import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class HttpClientService {

    private final HttpClient client;

    // Constructor para inicializar el cliente HTTP
    public HttpClientService() {
        this.client = HttpClient.newHttpClient();
    }

    // Método para hacer solicitudes GET y obtener la respuesta como String
    public String sendGetRequest(URI uri) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        return response.body();
    }
}
