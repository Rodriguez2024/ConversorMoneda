import java.io.IOException;
import java.net.URI;

public class ApiService {

    private final HttpClientService httpClientService;

    // Constructor para inyectar el servicio de cliente HTTP
    public ApiService(HttpClientService httpClientService) {
        this.httpClientService = httpClientService;
    }

    // Método para hacer una solicitud GET específica y procesar la respuesta
    public String getConversionRates() throws IOException, InterruptedException {
        URI uri = URI.create("https://api.example.com/conversion_rates");
        return httpClientService.sendGetRequest(uri);
    }
}
