import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        HttpClientService httpClientService = new HttpClientService();
        ApiService apiService = new ApiService(httpClientService);

        /*
        Moneda [] moneda = {
            new Moneda("USD", 1),
            new Moneda("AUD", 1.4817),
            new Moneda("BGN", 1.7741),
            new Moneda("CAD", 1.3168),
            new Moneda("CHF", 0.9774),
            new Moneda("CNY", 6.9454),
            new Moneda("EGP", 15.7361),
            new Moneda("EUR", 0.9013),
            new Moneda("GBP", 0.7679)
            };

        System.out.println(moneda[8]);
         */

        try {
            String conversionRates = apiService.getConversionRates();
            System.out.println("Conversion Rates: " + conversionRates);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

